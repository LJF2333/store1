#使用+，-号实现两个数的调换
A=56
B=78
A=A+B
B=A-B
A=A-B
print("A为：",A,"B为：",B)
