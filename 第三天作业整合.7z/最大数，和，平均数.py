#从键盘依次输入10个数，最后打印最大的数、10个数的和、和平均数。
sum=0
i=0
max=0
while i<10:
    num=input("请输入数字：")
    num=int(num)
    sum=num+sum
    i=i+1
    if num>max:
        max=num
    print(sum)
    print(sum/10)
    print(max)



