sum=0
i=0
while i<10:
    num=input("请输入数字 ： ")
    num=int(num)
    sum=num+sum
    i=i+1
print("10个数字的和为：",sum)

