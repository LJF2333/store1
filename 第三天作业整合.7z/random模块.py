import random
num=random.randint(50,150)
num=input(num)
num=int(num)
print(num)
