#一只青蛙掉在井里了，井高20米，青蛙白天往上爬3米，晚上下滑2米，问第几天能出来？
well=-20
up=3
down=-2
num=1
while well<0:
    print('day ',num,end="  ")
    well+=up
    print('up',well,end="  ")
    if well>=0:
        break
    well+=down
    print('down',well)
    if well>=0:
     break
    num+=1



