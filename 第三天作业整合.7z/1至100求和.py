#使用while编程实现求1~100以内的数的和！
num=0
i=1
while i<101:
    num=i+num
    i = i + 1
    print("1至100的和为：",num,i-1)