#实现登陆系统的三次密码输入错误锁定功能（name：root,password：admin）
i=0
while i<3:
    name=input("用户名：")
    password=input("密码：")
    if name=="root":
        if password=="admin":
            print("登录成功！")
            break
        else:print("密码错误，请重新输入")
        i=i+1
        if i==3:
         print("连续输错3次，系统被锁定！")
         break
        else:
         continue
    else:
     print("用户名输入错误，请重新输入")
     i=i+1
    if i==3:
        print("连续输错3次，系统被锁定")
        break
    else:
       continue


