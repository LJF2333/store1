a=input("输入边长a：")
a=int(a)
b=input("输入边长b：")
b=int(b)
c=input("输入边长c：")
c=int(c)
if a==b and a==c and a+b>c and a+c>b and b+c>a and a-c<b and a-b<c and  c-b<a and b-c<a:
    print("为等边三角形")
elif a==b or a==c or b==c and a+b>c and a+c>b and b+c>a and a-b<c and a-c<b and b-c<a and b-a<c and c-b<a and c-a<b:
    print("为等腰三角形")
elif a*a+b*b==c*c and a+b>c and a+c>b and b+c>a and a-b<c and a-c<b and b-a<c and b-c<a and c-a<b and c-b<a:
    print("为直角三角形")
elif a+b>c and a+c>b and b+c>a and a-b<c and a-c<b and b-a<c and b-c<a and c-a<b and c-b<a:
    print("为普通三角形")
else:
    print("这不是三角形")